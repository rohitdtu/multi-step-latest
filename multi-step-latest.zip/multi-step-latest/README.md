# multi-step-poc

Multiple steps form using Formik + YUP + Material UI

# Install dependencies
npm install

# Serve on localhost:3000
npm start

# Build for production
npm run build
