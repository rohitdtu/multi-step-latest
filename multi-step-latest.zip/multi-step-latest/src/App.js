import React from 'react';
import { UserForm } from './components/UserForm';
import { connect } from 'react-redux';

const App = ({userDetails}) => {
  console.log(userDetails);
  return (
    <UserForm
      userDetails={userDetails}
    />
  );
};

const mapStateToProps = (state) => ({
  userDetails: state.userDetails.userDetails,
});

export default connect(mapStateToProps)(App);