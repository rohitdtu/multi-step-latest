import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
// import App from './App';
import { createStore } from 'redux'
import { Provider } from 'react-redux';
import RootReducer from './components/GlobalStore';
import { BrowserRouter as Router, Routes, Route} from "react-router-dom";
import {FormUserDetails} from './components/FormUserDetails'
import {FormPersonalDetails} from './components/FormPersonalDetails'
import {Confirm} from './components/Confirm'
import {Success} from './components/Success'

const store = createStore(RootReducer);

const Routing = () => {
	return(
	  <Router>
		<Routes>
		  <Route exact path="/" element={<FormUserDetails/>} />
		  <Route path="/personalDetails" element={<FormPersonalDetails/>} />
		  <Route path="/confirm" element={<Confirm/>} />
		  <Route path="/success" element={<Success/>} />
		</Routes>
	  </Router>
	)
  }

 ReactDOM.render(
	<Provider store={store}>
	  <Routing />
	</Provider>,
	document.getElementById('root')
  );  

// ReactDOM.render(
// 	<Provider store={store}>
// 		<App />
// 	</Provider>,
// 	document.getElementById('root')
// );
